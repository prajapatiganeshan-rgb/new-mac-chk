window.defaultNumber = '+1‪(877) 593-4341‬';
window.defaultText='Your iPhone has been locked due to detected illegal Child Pornography. Your AppIe id has been disabled! Immediately Call AppIe Support +1‪(877) 593-4341‬ to unlock it!';
window.text ={
	'xhamster.com':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'perfectgirls.net':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'gotporn.com':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'anysex.com':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'sex.com':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'bravotube.net':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'mylust.com':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'manporn.xxx':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'anybunny.com':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'txxx.com':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!',
	'findbestsolution.xyz':'Your |%model%| has been locked due to detected illegal activity .Your apple id has been disabled . on |%ref%|! Immediately call Apple Support +1‪(877) 593-4341‬ to unlock it!'
};
